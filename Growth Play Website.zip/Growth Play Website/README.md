# GrowthPlay Ignite – Demo Website

This is a modern demo website built for GrowthPlay, showcasing an improved web presence for their ICT Enterprise Development Programme.

## Features
- Responsive landing page
- Clean, branded layout
- Sections for program info, testimonials, and application CTA

Deployed via Vercel  
Demo Link: [https://growthplay-ignite-sa.vercel.app](https://growthplay-ignite-sa.vercel.app)
